//plik do roznyc funkcji, by nie zasmiecac main
#include <Arduino.h>